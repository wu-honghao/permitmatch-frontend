import { message } from "antd"
import { postAPI } from "../../api/api"
import type { JobFormValues } from "../../types/job"
import JobForm from "./Form/JobForm"
import { useTranslation } from "react-i18next"
import { useNavigate } from "react-router"
import { cleanJobData } from "../../utils/jobFormatters"

function JobNew () {
    const { t } = useTranslation()
    const navigate = useNavigate()

    const handleSubmit = async (values: JobFormValues) => {
        try{
            const payload = cleanJobData(values);
            
            const result = await postAPI({ url: '/jobs', data: payload, headersOption: { isAuthorization: true }})
        
            message.success(`${t("common.submit.success")}`)

            navigate(`/jobs/${result.data._id}`)
        }catch(e){
            console.log(e)

            message.error(`${t("common.submit.fail")}`)
        }
    }

    return <div>
        <JobForm onSubmit={handleSubmit} />
    </div>
}

export default JobNew